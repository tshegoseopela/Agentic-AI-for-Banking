import typer
from typing_extensions import Annotated, List
from ibm_watsonx_orchestrate.cli.commands.agents.agents_controller import AgentsController
from ibm_watsonx_orchestrate.agent_builder.agents.types import DEFAULT_LLM, AgentKind, AgentStyle

agents_app = typer.Typer(no_args_is_help=True)


@agents_app.command(name="import")
def agent_import(
    file: Annotated[
        str,
        typer.Option("--file", "-f", help="YAML file with agent definition"),
    ],
):
    agents_controller = AgentsController()
    agent_specs = agents_controller.import_agent(file=file)
    agents_controller.publish_or_update_agents(agent_specs)


@agents_app.command(name="create")
def agent_create(
    name: Annotated[
        str,
        typer.Option("--name", "-n", help="Name of the agent you wish to create"),
    ],
    kind: Annotated[
        AgentKind,
        typer.Option("--kind", "-k", help="The kind of agent you wish to create"),
    ] = AgentKind.NATIVE,
    description: Annotated[
        str,
        typer.Option(
            "--description",
            help="Description of the agent",
        ),
    ] = None,
    llm: Annotated[
        str,
        typer.Option(
            "--llm",
            help="The LLM used by the agent",
        ),
    ] = DEFAULT_LLM,
    style: Annotated[
        AgentStyle,
        typer.Option("--style", help="The style of agent you wish to create"),
    ] = AgentStyle.DEFAULT,
    collaborators: Annotated[
        List[str],
        typer.Option(
            "--collaborators",
            help="A list of agent names you wish for the agent to be able to collaborate with. Format --colaborators agent1 --collaborators agent2 ...",
        ),
    ] = None,
    tools: Annotated[
        List[str],
        typer.Option(
            "--tools",
            help="A list of tool names you wish for the agent to be able to utilise. Format --tools tool1 --tools agent2 ...",
        ),
    ] = None,
    output_file: Annotated[
        str,
        typer.Option(
            "--output",
            "-o",
            help="Write the agent definition out to a YAML (.yaml/.yml) file or a JSON (.json) file.",
        ),
    ] = None,
):
    agents_controller = AgentsController()
    agent = agents_controller.generate_agent_spec(
        name=name,
        kind=kind,
        description=description,
        llm=llm,
        style=style,
        collaborators=collaborators,
        tools=tools,
        output_file=output_file,
    )
    agents_controller.publish_or_update_agents([agent])

@agents_app.command(name="list")
def list_agents(
    kind: Annotated[
        AgentKind,
        typer.Option("--kind", "-k", help="The kind of agent you wish to create"),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="List full details of all agents in json format"),
    ] = False,
):  
    agents_controller = AgentsController()
    agents_controller.list_agents(kind=kind, verbose=verbose)

@agents_app.command(name="remove")
def remove_agent(
    name: Annotated[
        str,
        typer.Option("--name", "-n", help="Name of the agent you wish to remove"),
    ],
    kind: Annotated[
        AgentKind,
        typer.Option("--kind", "-k", help="The kind of agent you wish to remove"),
    ]
):  
    agents_controller = AgentsController()
    agents_controller.remove_agent(name=name, kind=kind)
